if($('#nombre_formato').text() == 'Entrevista Telefónica'){
	$('#horario_table_text_space').text("Día de la semana");
}

if($('#nombre_formato').text() == 'Historia Psicológica de Clientes Menores de Edad'){
	$('#conductas_preescolar_text_space').text("Conducta");
	$('#instituciones_educativas_text_space').text("Etapa Escolar");
	$('#problemas_escolares_text_space').text("Problema");
	$('#enfermedades_condiciones_menor_text_space').text("Enfermedad/Condición");
	$('#enfermedades_condiciones_familiar_text_space').text("Enfermedad/Condición");
	$('#conductas_problemas_menor_text_space').text("Conducta/Problema");
	$('#aspectos_padres_poseen_text_space').text("Aspecto");
	$('#tecnica_disciplinaria_usada_text_space').text("Técnica disciplinaria");
	$('#tecnica_disciplinaria_usada_text_space').text("Técnica disciplinaria");
}

if($('#nombre_formato').text() == 'Información General de Cliente Adulto'){
	$('#padecimiento_enfermedad_adulto_text_space').text("Padecimiento");
	$('#problematica_buscar_adulto_text_space').text("Problemática");
}

if($('#nombre_formato').text() == 'Notas de Sesión Inicial en Servicios Clínicos'){
	$('#areas_afectadas_text_space').text("Area Afectada");
}

if($('#nombre_formato').text() == 'Encuesta de Satisfacción del Cliente en Servicios'){
	$('#nivel_satisfaccion').text("Preguntas");
}

if($('#nombre_formato').text() == 'Encuesta de Satisfacción del Cliente en Servicios'){
	$('#nivel_satisfaccion').text("Preguntas");
}

