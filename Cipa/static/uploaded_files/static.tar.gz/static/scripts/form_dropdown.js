var dropdown_genero = {
    'masculino' : 'masculino',
    'femenino' : 'femenino'
};

var dropdown_servicio_cipa = {
    'Psicoterapia' : 'Psicoterapia',
    'Consejería' : 'Consejería',
    'Evaluación Psicológica' : 'Evaluación Psicológica',
    'Evaluación Psicoeducativa' : 'Evaluación Psicoeducativa',
    'Otro' : 'Otro'
};

var dropdown_si_no = {
    'Si' : 'Si',
    'No' : 'No'
};

var dropdown_proceso_legal = {
    'Custodia' : 'Custodia',
    'Orden de alejamiento' : 'Orden de alejamiento',
    'Otro' : 'Otro'
};

var dropdown_servicio_cipa_2 = {
    'Psicoterapia' : 'Psicoterapia',
    'Consejería' : 'Consejería',
    'Evaluación Psicológica' : 'Evaluación Psicológica',
    'Evaluación Psicoeducativa' : 'Evaluación Psicoeducativa',
    'Intervención Psicoeducativa' : 'Intervención Psicoeducativa',
    'Otro' : 'Otro'
};

var dropdown_tipo_estudiante = {
	'Estudiante de Licenciatura en Psicología' : 'Estudiante de Licenciatura en Psicología',
	'Estudiante de Maestría en Consejería Psicológica y Salud Mental' : 'Estudiante de Maestría en Consejería Psicológica y Salud Mental',
	'Estudiante de Maestría en Neuropsicología Clínica' : 'Estudiante de Maestría en Neuropsicología Clínica'
}

var dropdown_estado_civil = {
	'Soltero(a)' : 'Soltero(a)',
	'Casado(a)' : 'Casado(a)',
	'Unión Libre' : 'Unión Libre',
	'Separado(a)' : 'Separado(a)',
	'Divorciado(a)' : 'Divorciado(a)',
	'Viudo(a)' : 'Viudo(a)',
	'Otro' : 'Otro'
}

var dropdown_pruebas_psicologicas = {
	'Personalidad' : 'Personalidad',
	'Neurológicos' : 'Neurológicos',
	'Inteligencia/Educativos' : 'Inteligencia/Educativos',
	'Síntomas' : 'Síntomas',
	'Otros' : 'Otros'
}

var dropdown_estatus_entrada = {
	'Crisis' : 'Crisis',
	'Urgente' : 'Urgente', 
	'Rutina' : 'Rutina',
	'Referido' : 'Referido',
	'Otro' : 'Otro'
}

var dropdown_gravedad_cliente = {
	'Grado 3: Necesita ayuda muy notable' : 'Grado 3: Necesita ayuda muy notable',
	'Grado 2: Necesita ayuda notable' : 'Grado 2: Necesita ayuda notable',
	'Grado 1: Necesita ayuda' : 'Grado 1: Necesita ayuda'
}

var dropdown_cronicidad_sintomas = {
	'Agudo (horas o días)' : 'Agudo (horas o días)',
	'Intermedio (entre uno y tres meses)' : 'Intermedio (entre uno y tres meses)',
	'Crónico (más de tres meses)' : 'Crónico (más de tres meses)'
}

var dropdown_red_apoyo = {
	'Amplia y débil' : 'Amplia y débil',
	'Escasa y débil' : 'Escasa y débil',
	'Amplia y fuerte' : 'Amplia y fuerte',
	'Escasa y fuerte' : 'Escasa y fuerte'
}

var dropdown_estado_cambio = {
	'Pre-Contemplación (Poca consciencia del problema y de la necesidad de un cambio)' : 'Pre-Contemplación (Poca consciencia del problema y de la necesidad de un cambio)',
	'Contemplación (Consciencia del problema y de la necesidad de un cambio, pero ausencia de compromiso con el cambio)' : 'Contemplación (Consciencia del problema y de la necesidad de un cambio, pero ausencia de compromiso con el cambio)',
	'Preparación (Compromiso con un plan de cambio y comunicación de esta decisión)' : 'Preparación (Compromiso con un plan de cambio y comunicación de esta decisión)',
	'Acción (Cambio activo a nivel afectivo/cognitivo/conductual)' : 'Acción (Cambio activo a nivel afectivo/cognitivo/conductual)',
	'Mantenimiento (Necesidad de mantener los cambios ya logrados y aprender a afrontar recaídas)' : 'Mantenimiento (Necesidad de mantener los cambios ya logrados y aprender a afrontar recaídas)'
}

var dropdown_nivel = {
	'Alto' : 'Alto',
	'Medio' : 'Medio',
	'Bajo' : 'Bajo'
}

var dropdown_modalidad_servicio = {
	'Individual' : 'Individual',
	'Grupal' : 'Grupal',
	'Familiar' : 'Familiar',
	'Pareja' : 'Pareja'
}

var dropdown_caracteristicas_pronostico = {
	'Con características de buen pronóstico' : 'Con características de buen pronóstico',
	'Con características de mal pronóstico' : 'Con características de mal pronóstico'
}

var dropdown_servicio_cipa_3 = {
    'Psicoterapia' : 'Psicoterapia',
    'Consejería' : 'Consejería',
    'Evaluación Psicológica' : 'Evaluación Psicológica',
    'Otro' : 'Otro'
};

var dropdown_rango_edad = {
	'15-17' : '15-17',
	'18-24' : '18- 24',
	'25-35' : '35-49',
	'50 o más' : '50 o más'
}

var dropdown_servicio_cipa_4 = {
    'Evaluación Psicológica' : 'Evaluación Psicológica',
    'Intervención psicoeducativa' : 'Intervención psicoeducativa',
    'Otro' : 'Otro'
};

if($('#nombre_formato').text() == 'Entrevista Telefónica'){
	$.each(dropdown_genero, function(val, text) {
		$('#genero').append( new Option(text,val,false) );
	});
	$.each(dropdown_servicio_cipa, function(val, text) {
		$('#servicio_cipa').append( new Option(text,val,false) );
		$('#servicio_cipa_2').append( new Option(text,val,false) );
	});
	$.each(dropdown_si_no, function(val, text) {
		$('#si_no_medicamento').append( new Option(text,val,false) );
		$('#si_no_legal').append( new Option(text,val,false) );
		$('#si_no_servicio').append( new Option(text,val,false) );	
	});

	$.each(dropdown_proceso_legal, function(val, text) {
		$('#proceso_legal').append( new Option(text,val,false) );
	});
}

if($('#nombre_formato').text() == 'Registro de Sesiones y Donativos'){
	$.each(dropdown_si_no, function(val, text) {
		$('#si_no_reduccion_monto').append( new Option(text,val,false) );
	});
}

if($('#nombre_formato').text() == 'Verificación de los Servicios'){
	$.each(dropdown_servicio_cipa_2, function(val, text) {
		$('#servicio_verificacion').append( new Option(text,val,false) );
	});
	$.each(dropdown_tipo_estudiante, function(val, text) {
		$('#estudiante_de').append( new Option(text,val,false) );
	});
}

//Aqui va el 5to (Menor de edad)

if($('#nombre_formato').text() == 'Escala de Ingresos/Donativos de Servicios Clínicos'){
	$.each(dropdown_si_no, function(val, text) {
		$('#si_no_realizado').append( new Option(text,val,false) );
	});
}

if($('#nombre_formato').text() == 'Información General de Cliente Adulto'){
	$.each(dropdown_genero, function(val, text) {
		$('#genero_adulto').append( new Option(text,val,false) );
	});
	$.each(dropdown_estado_civil, function(val, text) {
		$('#estado_civil_adulto').append( new Option(text,val,false) );
	});
	$.each(dropdown_si_no, function(val, text) {
		$('#si_no_cuidado_medico_adulto').append( new Option(text,val,false) );
		$('#si_no_asiste_adulto').append( new Option(text,val,false) );
		$('#si_no_hospitalizado_adulto').append( new Option(text,val,false) );
		$('#si_no_pruebas_psico_adulto').append( new Option(text,val,false) );
	});
	$.each(dropdown_pruebas_psicologicas, function(val, text) {
		$('#tests_aplicados_adulto').append( new Option(text,val,false) );
	});
}

if($('#nombre_formato').text() == 'Notas de Sesión Inicial en Servicios Clínicos'){
	$.each(dropdown_estatus_entrada, function(val, text) {
		$('#estatus_entrada').append( new Option(text,val,false) );
	});
	$.each(dropdown_gravedad_cliente, function(val, text) {
		$('#nivel_gravedad_cliente').append( new Option(text,val,false) );
	});
	$.each(dropdown_cronicidad_sintomas, function(val, text) {
		$('#cronicidad_sintomas_cliente').append( new Option(text,val,false) );
	});
	$.each(dropdown_red_apoyo, function(val, text) {
		$('#tipo_red_apoyo').append( new Option(text,val,false) );
	});
	$.each(dropdown_estado_cambio, function(val, text) {
		$('#estado_cambio').append( new Option(text,val,false) );
	});
	$.each(dropdown_nivel, function(val, text) {
		$('#nivel_motivacion').append( new Option(text,val,false) );
		$('#nivel_resistencia').append( new Option(text,val,false) );
		$('#nivel_reactancia').append( new Option(text,val,false) );
	});
	$.each(dropdown_si_no, function(val, text) {
		$('#si_no_historia_legal').append( new Option(text,val,false) );
		$('#si_no_necesidad_evaluaciones').append( new Option(text,val,false) );
	});
	$.each(dropdown_modalidad_servicio, function(val, text) {
		$('#modalidad_servicio_necesita').append( new Option(text,val,false) );
	});
	$.each(dropdown_caracteristicas_pronostico, function(val, text) {
		$('#caracteristicas_pronostico').append( new Option(text,val,false) );
	});	
}
if($('#nombre_formato').text() == 'Notas de Progreso (SOEP)'){
	$.each(dropdown_caracteristicas_pronostico, function(val, text) {
		$('#caracteristicas_pronostico').append( new Option(text,val,false) );
	});	
}

if($('#nombre_formato').text() == 'Encuesta de Satisfacción del Cliente en Servicios'){
	$.each(dropdown_servicio_cipa_3, function(val, text) {
		$('#servicios_recibidos').append( new Option(text,val,false) );
	});
	$.each(dropdown_genero, function(val, text) {
		$('#genero_responde').append( new Option(text,val,false) );
	});
	$.each(dropdown_rango_edad, function(val, text) {
		$('#rango_edad_responde').append( new Option(text,val,false) );
	});
	$.each(dropdown_tipo_estudiante, function(val, text) {
		$('#profesional_responde').append( new Option(text,val,false) );
	});
}

if($('#nombre_formato').text() == 'Escala de Ingresos/Donativos de Servicios Psicoeducativos'){
	$.each(dropdown_si_no, function(val, text) {
		$('#si_no_donativo').append( new Option(text,val,false) );
	});
}

if($('#nombre_formato').text() == 'Encuesta de Satisfacción del Cliente en Servicios'){
	$.each(dropdown_servicio_cipa_3, function(val, text) {
		$('#servicios_recibio_cipa').append( new Option(text,val,false) );
	});
	$.each(dropdown_genero, function(val, text) {
		$('#genero_responde').append( new Option(text,val,false) );
	});
	$.each(dropdown_rango_edad, function(val, text) {
		$('#rango_edad_responde').append( new Option(text,val,false) );
	});
}




