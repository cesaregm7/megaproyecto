$(function() {
    $( ".date_picker" ).datepicker({
        dateFormat:"dd/mm/yy"
    });
 });
 
$( function() {
    var etiquetasMotivoConsulta = [
      "Trastorno Déficit de Atención",
      "Trastorno Déficit de Atención con Hiperactividad",
      "Autismo",
      "Problemas de Aprendizaje",
      "Déficit Intelectual",
      "Admisión Académica",
      "Habilidad General",
      "Problemas del Habla",
      "Problemas Escolares",
      "Problemas Conductuales",
      "Duelos",
      "Divorcio",
      "Dificultades Familiares",
      "Manejo de Emociones",
      "Relaciones Interpersonales",
      "Trauma",
      "Trastornos del Desarrollo",
      "Trastorno Degenerativo",
      "Anoxia",
      "Epilepsia",
      "Depresión",
      "Ansiedad",
      "Trastorno Obsesivo Compulsivo",
      "Trastornos Alimentarios",
      "Trastorno de la Personalidad",
      "OTROS"
    ];
    function split( val ) {
      return val.split( /,\s*/ );
    }
    function extractLast( term ) {
      return split( term ).pop();
    }
 
    $( "#id_consultation_reason" )
      // don't navigate away from the field on tab when selecting an item
      .on( "keydown", function( event ) {
        if ( event.keyCode === $.ui.keyCode.TAB &&
            $( this ).autocomplete( "instance" ).menu.active ) {
          event.preventDefault();
        }
      })
      .autocomplete({
        minLength: 0,
        source: function( request, response ) {
          // delegate back to autocomplete, but extract the last term
          response( $.ui.autocomplete.filter(
            etiquetasMotivoConsulta, extractLast( request.term ) ) );
        },
        focus: function() {
          // prevent value inserted on focus
          return false;
        },
        select: function( event, ui ) {
          var terms = split( this.value );
          // remove the current input
          terms.pop();
          // add the selected item
          terms.push( ui.item.value );
          // add placeholder to get the comma-and-space at the end
          terms.push( "" );
          this.value = terms.join( ", " );
          return false;
        }
      });
  } );
  
  $( function() {
    var etiquetasDiagnostico = [
      "Discapacidad Intelectual","Discapacidad Moderado","Discapacidad Grave","Discapacidad Profundo",
      "Retraso General del Desarrollo",
      "Trastornos de la Comunicación (del Lenguaje)", "Trastornos de la Comunicación (Fonológico)", "Trastornos de la Comunicación (de Fluidez -Tartamudeo-)",
      "Autismo",
      "Trastorno Déficit de Atención",
      "Trastorno Déficit de Atención con Hiperactividad",
      "Trastorno Específico del Aprendizaje (Dislexia)", "Trastorno Específico del Aprendizaje (Disgrafia)", "Trastorno Específico del Aprendizaje (Discalculia)",
      "Trastornos Motores (del desarrollo de la coordinación)", "Trastornos Motores (de Movimientos Estereotipados)", "Trastornos Motores (de la Tourette)", "Trastornos Motores (de Tics motores o vocales)", "Trastornos Motores (de Tic transitorio)",
      "Esquizofrenia y otros Trastornos Psicóticos (Trastorno Esquizotípico de la personalidad)", "Esquizofrenia y otros Trastornos Psicóticos (Trastorno de Delirios)", "Esquizofrenia y otros Trastornos Psicóticos (Trastorno Esquizofreniforme)", "Esquizofrenia y otros Trastornos Psicóticos (Esquizofrenia)", "Esquizofrenia y otros Trastornos Psicóticos (Trastorno Esquizoafectivo)", "Esquizofrenia y otros Trastornos Psicóticos (Trastorno Psicótico inducido por sustancias)", "Esquizofrenia y otros Trastornos Psicóticos (Trastorno Psicótico por afección médica)",
      "Trastorno Bipolar (I)", "Trastorno Bipolar (II)", "Trastorno Bipolar (Trastorno Ciclotímico)",
      "Trastornos Depresivos (Trastorno de Depresión Mayor)", "Trastornos Depresivos (Distimia)", "Trastornos Depresivos (Trastorno Disfórico Premenstrual)", 
      "Trastornos de Ansiedad (Trastorno de Ansiedad por Separación)", "Trastornos de Ansiedad (Mutismo Selectivo)", "Trastornos de Ansiedad (Fobia Específica)", "Trastornos de Ansiedad (Fobia Social)", "Trastornos de Ansiedad (Trastorno de Pánico)", "Trastornos de Ansiedad (Agorafobia)","Trastornos de Ansiedad (Trastorno de ansiedad generalizada)",
      "Trastorno Obsesivo Compulsivo (Trastorno Dismórfico Corporal)", "Trastorno Obsesivo Compulsivo (Trastorno de Acumulación)", "Trastorno Obsesivo Compulsivo (Tricotilomanía)", "Trastorno Obsesivo Compulsivo (Trastorno de excoriación)",
      "Trastorno Relacionado con Trauma (Trastorno de Apego Reactivo)", "Trastorno Relacionado con Trauma (Trastorno de relación social desinhibida)", "Trastorno Relacionado con Trauma (Trastorno de Estrés Postraumático)", "Trastorno Relacionado con Trauma (Trastorno de Estrés Agudo)",
      "Trastornos de Síntomas Somáticos (Trastorno de ansiedad por enfermedad)", "Trastornos de Síntomas Somáticos (Trastorno Facticio)",
      "Trastornos Alimentarios y de Ingestión de Alimentos (Pica)", "Trastornos Alimentarios y de Ingestión de Alimentos (Trastorno de rumiación)", "Trastornos Alimentarios y de Ingestión de Alimentos (Trastorno de restricción de ingesta de alimentos)", "Trastornos Alimentarios y de Ingestión de Alimentos (Anorexia Nerviosa)", "Trastornos Alimentarios y de Ingestión de Alimentos (Bulimia Nerviosa)", "Trastornos Alimentarios y de Ingestión de Alimentos (Trastorno por Atracón)",
      "Trastorno de la Excresión (Enuresis)", "Trastorno de la Excresión (Encopresis)",
      "Trastornos del Sueño-Vigilia (Trastorno de Insomnio)", "Trastornos del Sueño-Vigilia (Trastorno por Hipersomnia)", "Trastornos del Sueño-Vigilia (Narcolepsia)",
      "Trastornos destructivos, del control de impulsos y de la conducta (Trastorno negativista desafiante)", "Trastornos destructivos, del control de impulsos y de la conducta (Trastorno explosivo intermitente)", "Trastornos destructivos, del control de impulsos y de la conducta (Trastorno de personalidad antisocial)", "Trastornos destructivos, del control de impulsos y de la conducta (Piromanía)", "Trastornos destructivos, del control de impulsos y de la conducta (Cleptomanía)",
      "Trastornos adictivos (Trastorno por consumo de alcohol)", "Trastornos adictivos (Trastorno por consumo de cannabis)", "Trastornos adictivos (Trastorno por consumo de fenciclidina)", "Trastornos adictivos (Trastorno por sedantes, hipnóticos o ansiolíticos)",
      "Trastornos de la personalidad (paranoide)", "Trastornos de la personalidad (esquizoide)", "Trastornos de la personalidad (esquizotípica)", "Trastornos de la personalidad (antisocial)", "Trastornos de la personalidad (límite)", "Trastornos de la personalidad (histriónica)", "Trastornos de la personalidad (narcicistia)", "Trastornos de la personalidad (evasiva)", "Trastornos de la personalidad (dependiente)", "Trastornos de la personalidad (obsesivo-compulsivo)",
      "Trastornos Parafílicos (Trastorno de Voyeurismo)", "Trastornos Parafílicos (Trastorno de exhibicionismo)", "Trastornos Parafílicos (Trastorno de froteurismo)", "Trastornos Parafílicos (Trastorno de masoquismo sexual)", "Trastornos Parafílicos (Trastorno de sadismo sexual)", "Trastornos Parafílicos (Trastorno de pedofilia)", "Trastornos Parafílicos (Trastorno de fetichismo)",
      "Negligencia",
      "Maltrato",
      "Abuso Sexual",
      "Problemas económicos",
      "Pruebas de Admisión",
      "Problemas Escolares",
      "Habilidad General",
      "Problemas del Habla",
      "Problemas Conductuales",
      "Duelos",
      "Divorcio",
      "Dificultades Familiares",
      "Manejo de Emociones",
      "Relaciones Interpersonales",
      "Trauma",
      "Trastorno Autoinmunológico",
      "Trastornos del Desarrollo",
      "Trastornos Degenerativos",
      "Trastornos por Deficiencias Nutricionales",
      "Trastornos por Toxicidad",
      "Tumores",
      "Accidentes Cerebrovasculares",
      "Anoxia",
      "Epilepsia",
      "Hidrocefalia",
      "Trastornos Infecciosos",
      "Metabólicos",
      "OTROS"
    ];
    function split( val ) {
      return val.split( /,\s*/ );
    }
    function extractLast( term ) {
      return split( term ).pop();
    }
 
    $( "#id_diagnosis" )
      // don't navigate away from the field on tab when selecting an item
      .on( "keydown", function( event ) {
        if ( event.keyCode === $.ui.keyCode.TAB &&
            $( this ).autocomplete( "instance" ).menu.active ) {
          event.preventDefault();
        }
      })
      .autocomplete({
        minLength: 0,
        source: function( request, response ) {
          // delegate back to autocomplete, but extract the last term
          response( $.ui.autocomplete.filter(
            etiquetasDiagnostico, extractLast( request.term ) ) );
        },
        focus: function() {
          // prevent value inserted on focus
          return false;
        },
        select: function( event, ui ) {
          var terms = split( this.value );
          // remove the current input
          terms.pop();
          // add the selected item
          terms.push( ui.item.value );
          // add placeholder to get the comma-and-space at the end
          terms.push( "" );
          this.value = terms.join( ", " );
          return false;
        }
      });
  } );
 
