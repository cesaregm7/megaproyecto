$('#horario_table > tbody:last-child').append('<tr><td>Lunes</td><td><input name="am_1" type="text" class="form-control"/></td> <td><input name="pm_1" type="text" class="form-control"/></td></tr>');
$('#horario_table > tbody:last-child').append('<tr><td>Martes</td><td><input name="am_2" type="text" class="form-control"/></td> <td><input name="pm_2" type="text" class="form-control"/></td></tr>');
$('#horario_table > tbody:last-child').append('<tr><td>Miercoles</td><td><input name="am_3" type="text" class="form-control"/></td> <td><input name="pm_3" type="text" class="form-control"/></td></tr>');
$('#horario_table > tbody:last-child').append('<tr><td>Jueves</td><td><input name="am_4" type="text" class="form-control"/></td> <td><input name="pm_4" type="text" class="form-control"/></td></tr>');
$('#horario_table > tbody:last-child').append('<tr><td>Viernes</td><td><input name="am_5" type="text" class="form-control"/></td> <td><input name="pm_5" type="text" class="form-control"/></td></tr>');
$('#horario_table > tbody:last-child').append('<tr><td>Sábado</td><td><input name="am_6" type="text" class="form-control"/></td> <td><input name="pm_6" type="text" class="form-control"/></td></tr>');






