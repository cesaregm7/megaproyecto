
function checkComplete()
{
	if (jQuery(".btn-group-justified").length == jQuery(".btn-success").length)
	{
		var questions = [];
		var answers = [];
		
		var form = jQuery("#test_form");
	
		jQuery("tr.tr-question").each(function ()
		{
			row = jQuery(this);
			var q = row.find("td.id-test-question").html();
			var a = row.find("a.btn-success").html();
			questions.push(q);
			answers.push(a);

			form.prepend("<input type=\"hidden\" name=\""+q+"\" value=\""+a+"\">\n");
		});

		jQuery(".invisible").removeClass("invisible");
	}
}
/*
// using jQuery
function getCookie(name) {
    var cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        var cookies = document.cookie.split(';');
        for (var i = 0; i < cookies.length; i++) {
            var cookie = jQuery.trim(cookies[i]);
            // Does this cookie string begin with the name we want?
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}

jQuery.ajaxSetup({ 
     beforeSend: function(xhr, settings) {
        if (!this.crossDomain) {
            xhr.setRequestHeader("csrfmiddlewaretoken", jQuery('input[name=csrfmiddlewaretoken]').attr("value"));
        }
     } 
});
*/
jQuery(".btn").click(function()
	{
		var clicked_btn = jQuery(event.target);
		var classList = clicked_btn.attr('class').split(/\s+/);
		
		if (jQuery.inArray("btn-submit", classList) == -1)
		{
			jQuery("."+classList[2]).removeClass("btn-success");
			clicked_btn.addClass("btn-success");
			checkComplete();
		}
		else
		{
			var questions = [];
			var answers = [];
			var token = jQuery('input[name=csrfmiddlewaretoken]').attr("value");

			jQuery("tr.tr-question").each(function ()
			{
				row = jQuery(this);
				questions.push(row.find("td.id-test-question").html());
				answers.push(row.find("a.btn-success").html());
			});

			//TODO borrar estas lineas
			//console.log(questions);
			//console.log(answers);
			//console.log(token);

			//jQuery.post("/test_result",
			//			{'csrfmiddlewaretoken':token,
			//					   'questions': questions, 
			//						 'answers': answers },
			//			function(data, status){
			//				//window.location.replace("/test_result");
//
//							var newDoc = document.open("text/html", "replace");
//							newDoc.write(data);
//							newDoc.close();
//						});

		}
	});
